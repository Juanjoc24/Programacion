

from Conex.conexionparcial import Conexionpar
conex=Conexionpar()
print("**********")

conex.conectar()
conex.desconectar()



